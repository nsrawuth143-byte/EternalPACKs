EternalSMP Hologram Logo Glyph (Java 1.21.11)

Install: put this ZIP in .minecraft/resourcepacks and enable it.
Font ID: eternal:icons
Glyph: U+E000 (private-use character)

MiniMessage example for a DecentHolograms text line (if your installed version supports MiniMessage font tags):
<font:eternal:icons>\uE000</font>

If the literal \uE000 is shown, copy the actual private-use character from the line below into your hologram text:
Glyph character: 

The uploaded .bbmodel is a Minecraft-title/font project with multiple text groups rather than a single pre-rendered logo. This pack includes a transparent EternalSMP wordmark inspired by the project and its red/silver texture palette; it is a 2D glyph, not a 3D model render.
